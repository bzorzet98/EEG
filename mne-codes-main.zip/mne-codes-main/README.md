# mne-codes
This repo will contain example codes using MNE
